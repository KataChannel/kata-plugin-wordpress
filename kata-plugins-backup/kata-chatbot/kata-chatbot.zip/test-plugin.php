<?php
/**
 * Test file for Kata Chatbot Plugin
 * 
 * Run this file to test the chatbot functionality
 * 
 * @package KataChatbot
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';
}

// Set error reporting for testing
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🤖 Kata Chatbot Plugin Test</h1>";

// Test 1: Check if plugin files exist
echo "<h2>📁 File Structure Test</h2>";
$required_files = [
    'kata-chatbot.php',
    'includes/class-ai-handler.php',
    'includes/class-db-handler.php', 
    'includes/class-chat-handler.php',
    'templates/admin-dashboard.php',
    'templates/chatbot-widget.php',
    'assets/css/admin.css',
    'assets/js/frontend.js'
];

$plugin_dir = dirname(__FILE__);
foreach ($required_files as $file) {
    $file_path = $plugin_dir . '/' . $file;
    if (file_exists($file_path)) {
        echo "✅ $file - OK<br>";
    } else {
        echo "❌ $file - MISSING<br>";
    }
}

// Test 2: Check WordPress integration
echo "<h2>🔗 WordPress Integration Test</h2>";

if (function_exists('add_action')) {
    echo "✅ WordPress functions available<br>";
    
    // Check if plugin is loaded
    if (class_exists('KataChatbot')) {
        echo "✅ KataChatbot class loaded<br>";
    } else {
        echo "❌ KataChatbot class not loaded<br>";
    }
    
} else {
    echo "❌ WordPress not loaded<br>";
}

// Test 3: Database connection
echo "<h2>💾 Database Test</h2>";

try {
    global $wpdb;
    
    if ($wpdb) {
        echo "✅ WordPress database connection available<br>";
        
        // Test database query
        $result = $wpdb->get_var("SELECT 1");
        if ($result == 1) {
            echo "✅ Database query successful<br>";
        } else {
            echo "❌ Database query failed<br>";
        }
        
        // Check if chatbot tables exist
        $tables_to_check = [
            $wpdb->prefix . 'kata_chatbot_conversations',
            $wpdb->prefix . 'kata_chatbot_messages',
            $wpdb->prefix . 'kata_chatbot_analytics',
            $wpdb->prefix . 'kata_chatbot_knowledge'
        ];
        
        foreach ($tables_to_check as $table) {
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
            if ($table_exists) {
                echo "✅ Table $table exists<br>";
            } else {
                echo "⚠️ Table $table does not exist (will be created on activation)<br>";
            }
        }
        
    } else {
        echo "❌ WordPress database not available<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Database error: " . $e->getMessage() . "<br>";
}

// Test 4: Class instantiation
echo "<h2>🏗️ Class Instantiation Test</h2>";

try {
    // Test AI Handler
    if (file_exists($plugin_dir . '/includes/class-ai-handler.php')) {
        require_once $plugin_dir . '/includes/class-ai-handler.php';
        
        if (class_exists('KataChatbot_AI_Handler')) {
            $ai_handler = new KataChatbot_AI_Handler();
            echo "✅ AI Handler instantiated successfully<br>";
        } else {
            echo "❌ AI Handler class not found<br>";
        }
    }
    
    // Test DB Handler
    if (file_exists($plugin_dir . '/includes/class-db-handler.php')) {
        require_once $plugin_dir . '/includes/class-db-handler.php';
        
        if (class_exists('KataChatbot_DB_Handler')) {
            $db_handler = new KataChatbot_DB_Handler();
            echo "✅ DB Handler instantiated successfully<br>";
        } else {
            echo "❌ DB Handler class not found<br>";
        }
    }
    
    // Test Chat Handler
    if (file_exists($plugin_dir . '/includes/class-chat-handler.php')) {
        require_once $plugin_dir . '/includes/class-chat-handler.php';
        
        if (class_exists('KataChatbot_Chat_Handler')) {
            // Note: Chat Handler requires AI and DB handlers
            if (isset($ai_handler) && isset($db_handler)) {
                $chat_handler = new KataChatbot_Chat_Handler();
                echo "✅ Chat Handler instantiated successfully<br>";
            } else {
                echo "⚠️ Chat Handler requires AI and DB handlers<br>";
            }
        } else {
            echo "❌ Chat Handler class not found<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Class instantiation error: " . $e->getMessage() . "<br>";
}

// Test 5: Configuration check
echo "<h2>⚙️ Configuration Test</h2>";

// Check Google AI API key
$api_key = get_option('kata_chatbot_google_api_key');
if ($api_key) {
    echo "✅ Google AI API key configured<br>";
    
    // Test API key format (should start with 'AIza')
    if (strpos($api_key, 'AIza') === 0) {
        echo "✅ API key format looks correct<br>";
    } else {
        echo "⚠️ API key format may be incorrect<br>";
    }
} else {
    echo "⚠️ Google AI API key not configured<br>";
}

// Check basic settings
$chatbot_enabled = get_option('kata_chatbot_enabled', true);
echo $chatbot_enabled ? "✅ Chatbot enabled<br>" : "⚠️ Chatbot disabled<br>";

$chatbot_name = get_option('kata_chatbot_name', 'Kata AI');
echo "ℹ️ Chatbot name: " . esc_html($chatbot_name) . "<br>";

// Test 6: AJAX endpoints
echo "<h2>🔗 AJAX Endpoints Test</h2>";

$ajax_actions = [
    'kata_chatbot_send_message',
    'kata_chatbot_submit_feedback',
    'kata_chatbot_save_quick_settings',
    'kata_chatbot_check_api_status'
];

foreach ($ajax_actions as $action) {
    if (has_action('wp_ajax_' . $action) || has_action('wp_ajax_nopriv_' . $action)) {
        echo "✅ AJAX action '$action' registered<br>";
    } else {
        echo "⚠️ AJAX action '$action' not registered (normal if plugin not activated)<br>";
    }
}

// Test 7: Template files
echo "<h2>📄 Template Test</h2>";

$templates = [
    'templates/admin-dashboard.php',
    'templates/chatbot-widget.php'
];

foreach ($templates as $template) {
    $template_path = $plugin_dir . '/' . $template;
    if (file_exists($template_path)) {
        echo "✅ Template $template exists<br>";
        
        // Check if template has basic structure
        $content = file_get_contents($template_path);
        if (strpos($content, '<?php') !== false) {
            echo "✅ Template $template has PHP code<br>";
        } else {
            echo "⚠️ Template $template may be missing PHP code<br>";
        }
    } else {
        echo "❌ Template $template missing<br>";
    }
}

// Test 8: Asset files
echo "<h2>🎨 Assets Test</h2>";

$assets = [
    'assets/css/admin.css',
    'assets/js/frontend.js'
];

foreach ($assets as $asset) {
    $asset_path = $plugin_dir . '/' . $asset;
    if (file_exists($asset_path)) {
        $size = filesize($asset_path);
        echo "✅ Asset $asset exists (" . round($size/1024, 2) . " KB)<br>";
    } else {
        echo "❌ Asset $asset missing<br>";
    }
}

// Test 9: Mock API test (without actual API call)
echo "<h2>🧪 Mock Functionality Test</h2>";

if (isset($chat_handler)) {
    try {
        // Test session ID generation
        $session_id = 'test_' . time() . '_' . wp_generate_password(8, false);
        echo "✅ Session ID generated: " . esc_html($session_id) . "<br>";
        
        // Test message sanitization
        $test_message = "Test message with <script>alert('xss')</script> content";
        $sanitized = sanitize_textarea_field($test_message);
        echo "✅ Message sanitization works<br>";
        
    } catch (Exception $e) {
        echo "❌ Mock test error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "⚠️ Chat handler not available for testing<br>";
}

// Test 10: Security check
echo "<h2>🔒 Security Test</h2>";

// Check nonce functions
if (function_exists('wp_create_nonce')) {
    $test_nonce = wp_create_nonce('kata_chatbot_test');
    echo "✅ Nonce generation works<br>";
    
    if (function_exists('wp_verify_nonce')) {
        $verified = wp_verify_nonce($test_nonce, 'kata_chatbot_test');
        echo $verified ? "✅ Nonce verification works<br>" : "❌ Nonce verification failed<br>";
    }
} else {
    echo "❌ Nonce functions not available<br>";
}

// Check sanitization functions
$test_inputs = [
    'sanitize_text_field',
    'sanitize_textarea_field', 
    'sanitize_email',
    'esc_html',
    'esc_attr'
];

foreach ($test_inputs as $func) {
    if (function_exists($func)) {
        echo "✅ Function $func available<br>";
    } else {
        echo "❌ Function $func not available<br>";
    }
}

// Summary
echo "<h2>📊 Test Summary</h2>";
echo "<p><strong>Test completed!</strong></p>";
echo "<p>If you see mostly ✅ green checkmarks, the plugin is ready to use.</p>";
echo "<p>⚠️ Warnings are normal if the plugin hasn't been activated yet.</p>";
echo "<p>❌ Red X marks indicate issues that need to be resolved.</p>";

echo "<h3>📋 Next Steps:</h3>";
echo "<ol>";
echo "<li>Activate the plugin in WordPress admin</li>";
echo "<li>Configure Google AI API key in settings</li>";
echo "<li>Test the chatbot widget on frontend</li>";
echo "<li>Check admin dashboard for analytics</li>";
echo "</ol>";

echo "<p><em>Test completed at: " . current_time('mysql') . "</em></p>";
?>
