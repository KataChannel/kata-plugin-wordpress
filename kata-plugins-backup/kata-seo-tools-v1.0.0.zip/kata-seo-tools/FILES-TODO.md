# KATA SEO TOOLS - DANH SÁCH FILES CẦN TẠO

## ✅ Files đã được tạo:

1. ✅ `kata-seo-tools.php` - Main plugin file
2. ✅ `includes/class-schema-generator.php` - Schema Markup Generator
3. ✅ `includes/class-social-share.php` - Social Share Handler
4. ✅ `README.md` - Documentation đầy đủ
5. ✅ `INSTALL.md` - Installation & Quick Start Guide

---

## 📝 FILES CẦN TẠO TIẾP (Code mẫu bên dưới)

### **A. INCLUDES (Handler Classes)**

#### 1. `includes/class-quote-generator.php`
```php
<?php
class Kata_SEO_Quote_Generator {
    public function render($atts, $content = null) {
        $atts = shortcode_atts(array(
            'style' => 'modern',
            'author' => '',
            'hashtags' => '',
            'bg_color' => '',
            'text_color' => '',
            'share' => 'no'
        ), $atts);
        
        $class = 'kata-quote kata-quote-' . esc_attr($atts['style']);
        $style_attr = '';
        
        if (!empty($atts['bg_color'])) {
            $style_attr .= 'background-color:' . esc_attr($atts['bg_color']) . ';';
        }
        if (!empty($atts['text_color'])) {
            $style_attr .= 'color:' . esc_attr($atts['text_color']) . ';';
        }
        
        ob_start();
        ?>
        <div class="<?php echo $class; ?>" style="<?php echo $style_attr; ?>">
            <div class="kata-quote-icon">"</div>
            <div class="kata-quote-content"><?php echo wp_kses_post($content); ?></div>
            
            <?php if (!empty($atts['author'])) : ?>
                <div class="kata-quote-author">— <?php echo esc_html($atts['author']); ?></div>
            <?php endif; ?>
            
            <?php if (!empty($atts['hashtags'])) : 
                $hashtags = explode(' ', $atts['hashtags']);
            ?>
                <div class="kata-quote-hashtags">
                    <?php foreach ($hashtags as $tag) : 
                        $tag = trim($tag);
                        if (strpos($tag, '#') === 0) :
                            $tag_url = 'https://twitter.com/hashtag/' . urlencode(substr($tag, 1));
                    ?>
                        <a href="<?php echo esc_url($tag_url); ?>" target="_blank" class="kata-hashtag"><?php echo esc_html($tag); ?></a>
                    <?php 
                        endif;
                    endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($atts['share'] === 'yes') : ?>
                <div class="kata-quote-share">
                    <button class="kata-quote-share-btn" onclick="kataSEO.shareQuote(this)">
                        <svg viewBox="0 0 24 24" width="16" height="16">
                            <path fill="currentColor" d="M18,16.08C17.24,16.08 16.56,16.38 16.04,16.85L8.91,12.7C8.96,12.47 9,12.24 9,12C9,11.76 8.96,11.53 8.91,11.3L15.96,7.19C16.5,7.69 17.21,8 18,8A3,3 0 0,0 21,5A3,3 0 0,0 18,2A3,3 0 0,0 15,5C15,5.24 15.04,5.47 15.09,5.7L8.04,9.81C7.5,9.31 6.79,9 6,9A3,3 0 0,0 3,12A3,3 0 0,0 6,15C6.79,15 7.5,14.69 8.04,14.19L15.16,18.34C15.11,18.55 15.08,18.77 15.08,19C15.08,20.61 16.39,21.91 18,21.91C19.61,21.91 20.92,20.61 20.92,19A2.92,2.92 0 0,0 18,16.08Z"/>
                        </svg>
                        Share Quote
                    </button>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
```

#### 2. `includes/class-quiz-handler.php`
```php
<?php
class Kata_SEO_Quiz_Handler {
    public function render($atts) {
        $atts = shortcode_atts(array(
            'id' => 'quiz-' . uniqid(),
            'title' => 'Quiz',
            'questions' => ''
        ), $atts);
        
        if (empty($atts['questions'])) {
            return '<p>No quiz data provided.</p>';
        }
        
        $questions = json_decode(base64_decode($atts['questions']), true);
        
        if (!$questions || !isset($questions['questions'])) {
            return '<p>Invalid quiz data.</p>';
        }
        
        ob_start();
        include KATA_SEO_PLUGIN_DIR . 'templates/frontend/quiz.php';
        return ob_get_clean();
    }
    
    public function submit_quiz($data) {
        global $wpdb;
        
        $quiz_id = sanitize_text_field($data['quiz_id']);
        $post_id = intval($data['post_id']);
        $answers = json_decode(stripslashes($data['answers']), true);
        
        $score = 0;
        $total = count($answers);
        
        foreach ($answers as $answer) {
            if (isset($answer['is_correct']) && $answer['is_correct']) {
                $score++;
            }
        }
        
        $table = $wpdb->prefix . 'kata_seo_quiz_results';
        $wpdb->insert($table, array(
            'post_id' => $post_id,
            'quiz_id' => $quiz_id,
            'score' => $score,
            'total_questions' => $total,
            'answers' => wp_json_encode($answers),
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'user_id' => get_current_user_id() ?: null
        ));
        
        return array(
            'score' => $score,
            'total' => $total,
            'percentage' => round(($score / $total) * 100, 2),
            'message' => $this->get_score_message($score, $total)
        );
    }
    
    private function get_score_message($score, $total) {
        $percentage = ($score / $total) * 100;
        
        if ($percentage >= 90) {
            return 'Xuất sắc! Bạn là chuyên gia!';
        } elseif ($percentage >= 70) {
            return 'Rất tốt! Bạn có kiến thức vững vàng!';
        } elseif ($percentage >= 50) {
            return 'Khá tốt! Hãy tiếp tục học hỏi!';
        } else {
            return 'Hãy cố gắng hơn! Thử lại nhé!';
        }
    }
}
```

#### 3. `includes/class-poll-handler.php`
```php
<?php
class Kata_SEO_Poll_Handler {
    public function render($atts) {
        $atts = shortcode_atts(array(
            'id' => 'poll-' . uniqid(),
            'question' => 'Poll Question',
            'options' => '[]'
        ), $atts);
        
        $options = json_decode($atts['options'], true);
        if (!$options) {
            $options = json_decode(base64_decode($atts['options']), true);
        }
        
        $results = $this->get_poll_results($atts['id']);
        $has_voted = $this->has_user_voted($atts['id']);
        
        ob_start();
        include KATA_SEO_PLUGIN_DIR . 'templates/frontend/poll.php';
        return ob_get_clean();
    }
    
    public function submit_vote($data) {
        global $wpdb;
        
        $poll_id = sanitize_text_field($data['poll_id']);
        $option_id = intval($data['option_id']);
        $post_id = intval($data['post_id']);
        
        $table = $wpdb->prefix . 'kata_seo_poll_votes';
        
        // Check if already voted
        if ($this->has_user_voted($poll_id)) {
            return array('error' => 'Bạn đã vote rồi!');
        }
        
        // Insert vote
        $wpdb->insert($table, array(
            'post_id' => $post_id,
            'poll_id' => $poll_id,
            'option_id' => $option_id,
            'user_id' => get_current_user_id() ?: null,
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ));
        
        return $this->get_poll_results($poll_id);
    }
    
    public function get_poll_results($poll_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'kata_seo_poll_votes';
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT option_id, COUNT(*) as votes FROM $table WHERE poll_id = %s GROUP BY option_id",
            $poll_id
        ), ARRAY_A);
        
        $total = array_sum(array_column($results, 'votes'));
        
        $formatted = array();
        foreach ($results as $result) {
            $formatted[$result['option_id']] = array(
                'votes' => $result['votes'],
                'percentage' => $total > 0 ? round(($result['votes'] / $total) * 100, 1) : 0
            );
        }
        
        return $formatted;
    }
    
    private function has_user_voted($poll_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'kata_seo_poll_votes';
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_id = get_current_user_id();
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE poll_id = %s AND (ip_address = %s OR user_id = %d)",
            $poll_id, $ip, $user_id
        ));
        
        return $count > 0;
    }
}
```

### **B. TEMPLATES**

Tạo trong `templates/frontend/`:

1. `quiz.php` - Quiz template
2. `poll.php` - Poll template  
3. `wheel.php` - Wheel template
4. `rating.php` - Rating template
5. `faq.php` - FAQ template
6. `cta.php` - CTA template
7. `form.php` - Form template

Tạo trong `templates/admin/`:

1. `dashboard.php` - Admin dashboard
2. `settings.php` - Settings page
3. `analytics.php` - Analytics page
4. `schema-meta-box.php` - Schema meta box
5. `social-meta-box.php` - Social meta box
6. `faq-meta-box.php` - FAQ meta box

### **C. ASSETS**

#### `assets/css/frontend.css`
```css
/* Schema & SEO */
.kata-schema-wrapper {
    display: none;
}

/* Social Share */
.kata-social-share {
    margin: 20px 0;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 8px;
}

.kata-social-title {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 12px;
    color: #333;
}

.kata-social-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.kata-social-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 6px;
    text-decoration: none;
    color: #333;
    transition: all 0.3s ease;
}

.kata-social-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.kata-social-btn svg {
    flex-shrink: 0;
}

.kata-social-circle .kata-social-btn {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    justify-content: center;
}

.kata-social-circle .kata-social-label {
    display: none;
}

/* Platform colors */
.kata-social-facebook:hover { background: #1877f2; color: white; border-color: #1877f2; }
.kata-social-twitter:hover { background: #1da1f2; color: white; border-color: #1da1f2; }
.kata-social-linkedin:hover { background: #0077b5; color: white; border-color: #0077b5; }
.kata-social-tiktok:hover { background: #000; color: white; border-color: #000; }

/* Quote */
.kata-quote {
    margin: 30px 0;
    padding: 30px;
    position: relative;
}

.kata-quote-modern {
    border-left: 4px solid #4A90E2;
    background: #f8f9fa;
    padding-left: 30px;
}

.kata-quote-icon {
    font-size: 60px;
    color: #4A90E2;
    line-height: 1;
    margin-bottom: 10px;
    font-family: Georgia, serif;
}

.kata-quote-content {
    font-size: 18px;
    line-height: 1.6;
    font-style: italic;
    margin-bottom: 15px;
}

.kata-quote-author {
    font-size: 16px;
    font-weight: 600;
    color: #666;
}

.kata-quote-hashtags {
    margin-top: 15px;
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.kata-hashtag {
    display: inline-block;
    padding: 4px 12px;
    background: #4A90E2;
    color: white;
    border-radius: 20px;
    font-size: 13px;
    text-decoration: none;
    transition: all 0.2s;
}

.kata-hashtag:hover {
    background: #357abd;
    transform: scale(1.05);
}

/* Quiz */
.kata-quiz {
    margin: 30px 0;
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
}

.kata-quiz .quiz-title {
    font-size: 24px;
    margin-bottom: 20px;
    color: #333;
}

.quiz-question {
    margin-bottom: 25px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 6px;
}

.question-text {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 15px;
}

.quiz-options {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.quiz-option {
    display: flex;
    align-items: center;
    padding: 12px;
    background: white;
    border: 2px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
}

.quiz-option:hover {
    border-color: #4A90E2;
    background: #f0f7ff;
}

.quiz-option input[type="radio"] {
    margin-right: 10px;
}

.quiz-submit-btn {
    margin-top: 20px;
    padding: 12px 30px;
    background: #4A90E2;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s;
}

.quiz-submit-btn:hover {
    background: #357abd;
    transform: translateY(-2px);
}

.quiz-result {
    margin-top: 20px;
    padding: 20px;
    background: #e8f5e8;
    border: 1px solid #4caf50;
    border-radius: 6px;
}

.quiz-score {
    font-size: 18px;
    font-weight: 600;
    color: #2e7d32;
}

/* Poll */
.kata-poll {
    margin: 30px 0;
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
}

.poll-question {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 20px;
}

.poll-options {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.poll-option {
    position: relative;
}

.poll-option label {
    display: flex;
    align-items: center;
    padding: 12px;
    background: #f8f9fa;
    border: 2px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
}

.poll-option label:hover {
    border-color: #4A90E2;
}

.poll-result-bar {
    margin-top: 8px;
    position: relative;
    height: 30px;
    background: #e0e0e0;
    border-radius: 4px;
    overflow: hidden;
}

.poll-bar {
    height: 100%;
    background: linear-gradient(90deg, #4A90E2, #357abd);
    transition: width 0.5s ease;
    display: flex;
    align-items: center;
    padding: 0 10px;
}

.poll-percentage {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-weight: 600;
    color: #333;
}

.poll-submit-btn {
    margin-top: 20px;
    padding: 12px 30px;
    background: #4A90E2;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

/* Rating */
.kata-rating {
    margin: 30px 0;
    padding: 30px;
    background: #f8f9fa;
    border-radius: 8px;
}

.kata-rating-stars {
    display: flex;
    gap: 5px;
    font-size: 30px;
    color: #ffc107;
    cursor: pointer;
}

.kata-rating-star {
    transition: all 0.2s;
}

.kata-rating-star:hover {
    transform: scale(1.2);
}

/* FAQ */
.kata-faq-accordion .kata-faq-item {
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 6px;
    overflow: hidden;
}

.kata-faq-question {
    padding: 15px 20px;
    background: #f8f9fa;
    cursor: pointer;
    font-weight: 600;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.kata-faq-question:hover {
    background: #e9ecef;
}

.kata-faq-answer {
    padding: 20px;
    display: none;
    background: white;
}

.kata-faq-item.active .kata-faq-answer {
    display: block;
}

/* CTA */
.kata-cta-box {
    margin: 30px 0;
    padding: 30px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 8px;
    text-align: center;
}

.kata-cta-button {
    display: inline-block;
    margin-top: 20px;
    padding: 15px 40px;
    background: white;
    color: #667eea;
    border: none;
    border-radius: 50px;
    font-size: 18px;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s;
}

.kata-cta-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* Responsive */
@media (max-width: 768px) {
    .kata-social-buttons {
        justify-content: center;
    }
    
    .quiz-question,
    .kata-poll,
    .kata-cta-box {
        padding: 20px;
    }
}
```

#### `assets/js/frontend.js`
```javascript
(function($) {
    'use strict';
    
    window.kataSEO = {
        
        // Track social share
        trackShare: function(platform, postId) {
            $.ajax({
                url: kataSEO.ajax_url,
                method: 'POST',
                data: {
                    action: 'kata_seo_track_share',
                    nonce: kataSEO.nonce,
                    platform: platform,
                    post_id: postId
                }
            });
        },
        
        // Share quote
        shareQuote: function(btn) {
            var quoteEl = $(btn).closest('.kata-quote');
            var text = quoteEl.find('.kata-quote-content').text();
            var author = quoteEl.find('.kata-quote-author').text();
            var shareText = '"' + text + '" ' + author;
            
            var url = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(shareText);
            window.open(url, '_blank', 'width=600,height=400');
        }
    };
    
    $(document).ready(function() {
        
        // Quiz functionality
        $('.quiz-submit-btn').on('click', function() {
            var quizEl = $(this).closest('.kata-quiz');
            var quizId = quizEl.data('quiz-id');
            var postId = quizEl.data('post-id');
            
            var answers = [];
            var allAnswered = true;
            
            quizEl.find('.quiz-question').each(function(index) {
                var selected = $(this).find('input[type="radio"]:checked');
                
                if (selected.length === 0) {
                    allAnswered = false;
                    return false;
                }
                
                answers.push({
                    question_index: index,
                    answer_index: selected.val(),
                    is_correct: selected.data('correct') === 1
                });
            });
            
            if (!allAnswered) {
                alert('Vui lòng trả lời tất cả câu hỏi!');
                return;
            }
            
            $.ajax({
                url: kataSEO.ajax_url,
                method: 'POST',
                data: {
                    action: 'kata_seo_submit_quiz',
                    nonce: kataSEO.nonce,
                    quiz_id: quizId,
                    post_id: postId,
                    answers: JSON.stringify(answers)
                },
                success: function(response) {
                    if (response.success) {
                        var result = response.data;
                        quizEl.find('.quiz-questions, .quiz-submit-btn').hide();
                        quizEl.find('.quiz-result').show();
                        quizEl.find('.quiz-score').html(
                            '<strong>' + result.score + '/' + result.total + '</strong> (' + result.percentage + '%)<br>' +
                            result.message
                        );
                    }
                }
            });
        });
        
        // Poll functionality
        $('.poll-submit-btn').on('click', function() {
            var pollEl = $(this).closest('.kata-poll');
            var pollId = pollEl.data('poll-id');
            var postId = pollEl.data('post-id');
            var selected = pollEl.find('input[type="radio"]:checked');
            
            if (selected.length === 0) {
                alert('Vui lòng chọn một đáp án!');
                return;
            }
            
            $.ajax({
                url: kataSEO.ajax_url,
                method: 'POST',
                data: {
                    action: 'kata_seo_submit_poll',
                    nonce: kataSEO.nonce,
                    poll_id: pollId,
                    post_id: postId,
                    option_id: selected.val()
                },
                success: function(response) {
                    if (response.success) {
                        var results = response.data;
                        
                        pollEl.find('.poll-option').each(function(index) {
                            var result = results[index] || {votes: 0, percentage: 0};
                            $(this).find('.poll-result-bar').html(
                                '<div class="poll-bar" style="width: ' + result.percentage + '%"></div>' +
                                '<span class="poll-percentage">' + result.percentage + '%</span>' +
                                '<span class="poll-votes">(' + result.votes + ' votes)</span>'
                            ).show();
                        });
                        
                        pollEl.find('input, button').prop('disabled', true);
                        alert('Cảm ơn bạn đã tham gia vote!');
                    } else {
                        alert(response.data || 'Có lỗi xảy ra');
                    }
                }
            });
        });
        
        // FAQ accordion
        $('.kata-faq-question').on('click', function() {
            var item = $(this).closest('.kata-faq-item');
            item.toggleClass('active');
            item.siblings().removeClass('active');
        });
        
        // Rating stars
        $('.kata-rating-star').on('click', function() {
            var rating = $(this).data('rating');
            $(this).siblings().removeClass('selected');
            $(this).addClass('selected').prevAll().addClass('selected');
            $(this).closest('.kata-rating').find('input[name="rating"]').val(rating);
        });
        
    });
    
})(jQuery);
```

---

## 📦 SCRIPT TẠO TỰ ĐỘNG TẤT CẢ FILES

Save script này thành `create-remaining-files.sh` và chạy:

```bash
#!/bin/bash

# Tạo các handler classes còn lại
touch includes/class-wheel-handler.php
touch includes/class-rating-handler.php
touch includes/class-faq-handler.php
touch includes/class-cta-handler.php
touch includes/class-form-handler.php
touch includes/class-admin.php

# Tạo frontend templates
mkdir -p templates/frontend
touch templates/frontend/quiz.php
touch templates/frontend/poll.php
touch templates/frontend/wheel.php
touch templates/frontend/rating.php
touch templates/frontend/faq.php
touch templates/frontend/cta.php
touch templates/frontend/form.php

# Tạo admin templates
mkdir -p templates/admin
touch templates/admin/dashboard.php
touch templates/admin/settings.php
touch templates/admin/analytics.php
touch templates/admin/schema-meta-box.php
touch templates/admin/social-meta-box.php
touch templates/admin/faq-meta-box.php

# Tạo assets
touch assets/css/frontend.css
touch assets/css/admin.css
touch assets/js/frontend.js
touch assets/js/admin.js

echo "✅ Đã tạo tất cả các files!"
```

---

## 🎯 PRIORITY ORDER (Tạo theo thứ tự)

1. **HIGH PRIORITY:**
   - ✅ class-quote-generator.php
   - ✅ class-quiz-handler.php
   - ✅ class-poll-handler.php
   - ✅ assets/css/frontend.css
   - ✅ assets/js/frontend.js

2. **MEDIUM PRIORITY:**
   - class-rating-handler.php
   - class-faq-handler.php
   - class-cta-handler.php
   - class-form-handler.php
   - templates/admin/schema-meta-box.php
   - templates/admin/social-meta-box.php

3. **LOW PRIORITY:**
   - class-wheel-handler.php
   - class-admin.php
   - templates/admin/dashboard.php
   - templates/admin/analytics.php
   - assets/css/admin.css
   - assets/js/admin.js

---

Bạn muốn tôi tạo file nào tiếp theo không? Hoặc tạo tất cả files còn lại?
