<?php
/**
 * KATA SEO Manager Shortcode Test & Activation
 * Script test và kích hoạt shortcode rendering
 */

// Include WordPress
require_once('wp-config.php');
require_once('wp-load.php');

echo "🚀 KATA SEO Manager Shortcode Activation Test\n";
echo "============================================\n\n";

// 1. Force re-activate plugin
echo "🔌 1. Re-activating KATA SEO Manager...\n";

// Deactivate first
deactivate_plugins('kata-seo-manager/kata-seo-manager.php', true);
echo "   ⏸️  Plugin deactivated\n";

// Reactivate
$result = activate_plugin('kata-seo-manager/kata-seo-manager.php');
if (is_wp_error($result)) {
    echo "   ❌ Activation failed: " . $result->get_error_message() . "\n";
} else {
    echo "   ✅ Plugin re-activated successfully\n";
}

// 2. Force load plugin file
echo "\n🔧 2. Force loading plugin...\n";
include_once(WP_PLUGIN_DIR . '/kata-seo-manager/kata-seo-manager.php');
echo "   ✅ Plugin file loaded\n";

// 3. Check shortcode registration
echo "\n📋 3. Checking shortcode registration...\n";
global $shortcode_tags;

$kata_shortcodes = array();
foreach ($shortcode_tags as $tag => $callback) {
    if (strpos($tag, 'kata_') === 0) {
        $kata_shortcodes[] = $tag;
    }
}

echo "   📊 Found " . count($kata_shortcodes) . " KATA shortcodes:\n";
foreach ($kata_shortcodes as $shortcode) {
    echo "      - {$shortcode}\n";
}

// 4. Test individual shortcodes
echo "\n🧪 4. Testing shortcode rendering...\n";

$test_shortcodes = array(
    'article' => '[kata_article title="Test Article" author="Test Author" category="Test" excerpt="Test excerpt"]',
    'recipe' => '[kata_recipe name="Test Recipe" description="Test recipe" ingredients="Test ingredient" instructions="Test instruction"]',
    'product' => '[kata_product name="Test Product" price="100000" currency="VND" description="Test product"]',
    'event' => '[kata_event name="Test Event" start_date="2024-12-01T10:00" location="Test Location"]',
    'faq' => '[kata_faq questions="Test Question?" answers="Test Answer"]'
);

foreach ($test_shortcodes as $type => $shortcode) {
    echo "   🔍 Testing {$type}...\n";
    
    $output = do_shortcode($shortcode);
    
    if (strpos($output, 'application/ld+json') !== false) {
        echo "      ✅ JSON-LD generated\n";
    } else {
        echo "      ❌ No JSON-LD found\n";
        echo "      📄 Output: " . substr(strip_tags($output), 0, 100) . "...\n";
    }
}

// 5. Test with real demo post
echo "\n📄 5. Testing with real demo post...\n";

$demo_posts = get_posts(array(
    'posts_per_page' => 1,
    'meta_key' => '_kata_seo_demo_post',
    'meta_value' => true,
    'post_status' => 'publish'
));

if (!empty($demo_posts)) {
    $post = $demo_posts[0];
    echo "   📝 Testing post: {$post->post_title}\n";
    
    // Setup post data
    global $wp_query, $post;
    $wp_query->in_the_loop = true;
    setup_postdata($post);
    
    $content = apply_filters('the_content', $post->post_content);
    
    if (strpos($content, 'application/ld+json') !== false) {
        echo "      ✅ JSON-LD Schema found in processed content\n";
        
        // Extract JSON-LD
        preg_match('/<script type="application\/ld\+json">(.*?)<\/script>/s', $content, $matches);
        if (!empty($matches[1])) {
            $json_data = json_decode($matches[1], true);
            if ($json_data) {
                echo "      📊 Schema type: " . ($json_data['@type'] ?? 'Unknown') . "\n";
                echo "      🎯 Valid JSON-LD structure\n";
            } else {
                echo "      ⚠️  Invalid JSON-LD format\n";
            }
        }
    } else {
        echo "      ❌ No JSON-LD Schema found\n";
        
        // Debug: Check if shortcode exists in content
        if (strpos($post->post_content, '[kata_') !== false) {
            echo "      🔧 Shortcode found in content but not processed\n";
            
            // Try manual shortcode processing
            $manual_output = do_shortcode($post->post_content);
            if (strpos($manual_output, 'application/ld+json') !== false) {
                echo "      ✅ Manual shortcode processing works\n";
            } else {
                echo "      ❌ Manual shortcode processing failed\n";
            }
        }
    }
    
    wp_reset_postdata();
}

// 6. Check database for schema data
echo "\n🗄️ 6. Checking database for schema data...\n";
global $wpdb;

$schema_table = $wpdb->prefix . 'kata_seo_schemas';
$schema_count = $wpdb->get_var("SELECT COUNT(*) FROM {$schema_table}");

echo "   📊 Schemas in database: {$schema_count}\n";

if ($schema_count == 0) {
    echo "   💾 Trying to populate schema data...\n";
    
    // Force process all demo posts
    foreach ($demo_posts as $post) {
        setup_postdata($post);
        do_shortcode($post->post_content);
    }
    wp_reset_postdata();
    
    $new_count = $wpdb->get_var("SELECT COUNT(*) FROM {$schema_table}");
    echo "   📈 New schema count: {$new_count}\n";
}

// 7. Check plugin hooks
echo "\n🔗 7. Checking plugin hooks...\n";

global $wp_filter;

$hooks_to_check = array(
    'the_content',
    'wp_head',
    'init',
    'wp_enqueue_scripts'
);

foreach ($hooks_to_check as $hook) {
    if (isset($wp_filter[$hook])) {
        $kata_hooks = array();
        foreach ($wp_filter[$hook]->callbacks as $priority => $callbacks) {
            foreach ($callbacks as $callback) {
                if (is_array($callback['function']) && is_object($callback['function'][0])) {
                    $class_name = get_class($callback['function'][0]);
                    if (strpos($class_name, 'KATA') !== false) {
                        $kata_hooks[] = $class_name . '::' . $callback['function'][1];
                    }
                } elseif (is_string($callback['function']) && strpos($callback['function'], 'kata') !== false) {
                    $kata_hooks[] = $callback['function'];
                }
            }
        }
        
        if (!empty($kata_hooks)) {
            echo "   ✅ {$hook}: " . implode(', ', $kata_hooks) . "\n";
        } else {
            echo "   ❌ {$hook}: No KATA hooks found\n";
        }
    }
}

// 8. Manual shortcode test with direct function call
echo "\n🔨 8. Manual shortcode function test...\n";

// Test if shortcode functions exist
$shortcode_functions = array(
    'kata_article_shortcode',
    'kata_recipe_shortcode', 
    'kata_product_shortcode'
);

foreach ($shortcode_functions as $func) {
    if (function_exists($func)) {
        echo "   ✅ Function {$func} exists\n";
        
        // Try calling directly
        $attrs = array('title' => 'Test', 'description' => 'Test desc');
        $result = call_user_func($func, $attrs);
        
        if (strpos($result, 'application/ld+json') !== false) {
            echo "      ✅ Direct function call produces JSON-LD\n";
        } else {
            echo "      ❌ Direct function call failed\n";
        }
    } else {
        echo "   ❌ Function {$func} not found\n";
    }
}

// 9. Generate final report
echo "\n📋 9. FINAL DIAGNOSTIC REPORT:\n";
echo "===============================\n";

$plugin_active = is_plugin_active('kata-seo-manager/kata-seo-manager.php');
$shortcodes_registered = count($kata_shortcodes);
$schema_data_count = $wpdb->get_var("SELECT COUNT(*) FROM {$schema_table}");

echo "🔌 Plugin Status: " . ($plugin_active ? "✅ Active" : "❌ Inactive") . "\n";
echo "📋 Shortcodes Registered: {$shortcodes_registered}\n";
echo "🗄️ Database Records: {$schema_data_count}\n";

if ($plugin_active && $shortcodes_registered > 0) {
    echo "🎉 STATUS: Plugin is working!\n";
    echo "📝 Recommendations:\n";
    echo "   1. Visit a demo post on frontend to see JSON-LD\n";
    echo "   2. Use View Source to check for <script type='application/ld+json'>\n";
    echo "   3. Test with Google Rich Results Testing Tool\n";
    echo "   4. Check KATA SEO Manager admin dashboard\n";
} else {
    echo "⚠️  STATUS: Issues detected\n";
    echo "🔧 Troubleshooting needed\n";
}

echo "\n✨ Diagnostic completed!\n";
?>