<?php
/**
 * Test Activation Script
 * 
 * Run this to test plugin activation manually
 */

// Load WordPress
require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';

echo "<h1>🚀 Kata Chatbot Activation Test</h1>";

// Check if plugin is already active
if (is_plugin_active('kata-chatbot/kata-chatbot.php')) {
    echo "<p>✅ Plugin is already active</p>";
} else {
    echo "<p>⚠️ Plugin is not active</p>";
}

// Test activation manually
echo "<h2>📋 Manual Activation Test</h2>";

try {
    // Include plugin file
    include_once ABSPATH . 'wp-content/plugins/kata-chatbot/kata-chatbot.php';
    
    // Get plugin instance
    $plugin = KataChatbot::get_instance();
    
    if ($plugin) {
        echo "✅ Plugin instance created successfully<br>";
        
        // Test activation method
        if (method_exists($plugin, 'activate')) {
            echo "✅ Activation method exists<br>";
            
            // Run activation (be careful - this will create tables)
            try {
                $plugin->activate();
                echo "✅ Activation completed successfully<br>";
                
                // Check if tables were created
                global $wpdb;
                $tables = [
                    $wpdb->prefix . 'kata_chatbot_conversations',
                    $wpdb->prefix . 'kata_chatbot_messages', 
                    $wpdb->prefix . 'kata_chatbot_analytics',
                    $wpdb->prefix . 'kata_chatbot_knowledge'
                ];
                
                echo "<h3>📊 Database Tables Check</h3>";
                foreach ($tables as $table) {
                    $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
                    if ($exists) {
                        echo "✅ Table $table created successfully<br>";
                    } else {
                        echo "❌ Table $table creation failed<br>";
                    }
                }
                
            } catch (Exception $e) {
                echo "❌ Activation error: " . $e->getMessage() . "<br>";
            }
        } else {
            echo "❌ Activation method not found<br>";
        }
    } else {
        echo "❌ Failed to create plugin instance<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Error loading plugin: " . $e->getMessage() . "<br>";
}

// Test admin class
echo "<h2>🔧 Admin Class Test</h2>";

if (class_exists('KataChatbot_Admin')) {
    echo "✅ Admin class exists<br>";
    
    try {
        // Don't actually create admin instance to avoid affecting admin area
        echo "✅ Admin class can be loaded<br>";
    } catch (Exception $e) {
        echo "❌ Admin class error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ Admin class not found<br>";
}

// Test database handlers
echo "<h2>💾 Database Handler Test</h2>";

if (class_exists('KataChatbot_DB_Handler')) {
    try {
        $db_handler = new KataChatbot_DB_Handler();
        echo "✅ DB Handler created successfully<br>";
        
        // Test basic method
        if (method_exists($db_handler, 'get_dashboard_stats')) {
            $stats = $db_handler->get_dashboard_stats();
            echo "✅ Dashboard stats method works<br>";
            echo "ℹ️ Total conversations: " . ($stats['total_conversations'] ?? 0) . "<br>";
        }
        
    } catch (Exception $e) {
        echo "❌ DB Handler error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ DB Handler class not found<br>";
}

// Test AI handler
echo "<h2>🤖 AI Handler Test</h2>";

if (class_exists('KataChatbot_AI_Handler')) {
    try {
        $ai_handler = new KataChatbot_AI_Handler();
        echo "✅ AI Handler created successfully<br>";
        
        // Check API key
        $api_key = get_option('kata_chatbot_google_api_key');
        if ($api_key) {
            echo "✅ API key is configured<br>";
        } else {
            echo "⚠️ API key not configured (test with dummy key)<br>";
            
            // Set temporary API key for testing
            update_option('kata_chatbot_google_api_key', 'AIzaSyDummy_Key_For_Testing');
        }
        
    } catch (Exception $e) {
        echo "❌ AI Handler error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ AI Handler class not found<br>";
}

// Test chat handler
echo "<h2>💬 Chat Handler Test</h2>";

if (class_exists('KataChatbot_Chat_Handler')) {
    try {
        $chat_handler = new KataChatbot_Chat_Handler();
        echo "✅ Chat Handler created successfully<br>";
        
        // Test session ID generation
        $reflection = new ReflectionClass($chat_handler);
        echo "✅ Chat Handler methods available<br>";
        
    } catch (Exception $e) {
        echo "❌ Chat Handler error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ Chat Handler class not found<br>";
}

echo "<h2>🎯 Conclusion</h2>";
echo "<p>If you see mostly green checkmarks, the plugin is working correctly!</p>";
echo "<p>Now you can safely activate it through WordPress admin.</p>";

echo "<h3>🔗 Quick Links</h3>";
echo "<ul>";
echo "<li><a href='" . admin_url('plugins.php') . "'>WordPress Plugins Page</a></li>";
echo "<li><a href='" . admin_url('admin.php?page=kata-chatbot') . "'>Kata Chatbot Dashboard</a> (after activation)</li>";
echo "</ul>";
?>
