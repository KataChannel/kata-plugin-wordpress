<?php
/**
 * Test Schema Types Page
 * 
 * Test if schema-types.php page is working correctly
 */

// Load WordPress
require_once('../../../wp-load.php');

// Must be admin
if (!current_user_can('manage_options')) {
    die('You must be an administrator to run this test.');
}

echo "<h1>KATA SEO Manager - Schema Types Page Test</h1>";
echo "<hr>";

// Test 1: Check if plugin is active
echo "<h2>Test 1: Plugin Status</h2>";
if (class_exists('KATA_SEO_Manager')) {
    echo "✅ KATA SEO Manager plugin is ACTIVE<br>";
    $instance = KATA_SEO_Manager::get_instance();
    echo "✅ Plugin instance created successfully<br>";
} else {
    echo "❌ KATA SEO Manager plugin is NOT active<br>";
    exit;
}

// Test 2: Check if menu is registered
echo "<h2>Test 2: Admin Menu Registration</h2>";
global $submenu;
if (isset($submenu['kata-seo-manager'])) {
    echo "✅ KATA SEO main menu registered<br>";
    foreach ($submenu['kata-seo-manager'] as $item) {
        if ($item[2] === 'kata-seo-schema-types') {
            echo "✅ Schema Types submenu found: " . $item[0] . "<br>";
            echo "   - Menu slug: " . $item[2] . "<br>";
            echo "   - Capability: " . $item[1] . "<br>";
        }
    }
} else {
    echo "❌ KATA SEO menu not registered<br>";
}

// Test 3: Check if callback method exists
echo "<h2>Test 3: Callback Method</h2>";
if (method_exists($instance, 'admin_schema_types_page')) {
    echo "✅ Method 'admin_schema_types_page' EXISTS<br>";
} else {
    echo "❌ Method 'admin_schema_types_page' DOES NOT EXIST<br>";
}

// Test 4: Check if schema-types.php file exists
echo "<h2>Test 4: Schema Types File</h2>";
$file_path = KATA_SEO_MANAGER_PLUGIN_DIR . 'admin/schema-types.php';
if (file_exists($file_path)) {
    echo "✅ File exists: " . $file_path . "<br>";
    echo "   - File size: " . filesize($file_path) . " bytes<br>";
    echo "   - Readable: " . (is_readable($file_path) ? 'Yes' : 'No') . "<br>";
} else {
    echo "❌ File NOT found: " . $file_path . "<br>";
}

// Test 5: Check if CSS file exists
echo "<h2>Test 5: Schema Types CSS</h2>";
$css_path = KATA_SEO_MANAGER_PLUGIN_DIR . 'assets/css/schema-types.css';
if (file_exists($css_path)) {
    echo "✅ CSS file exists: " . $css_path . "<br>";
    echo "   - File size: " . filesize($css_path) . " bytes<br>";
} else {
    echo "❌ CSS file NOT found: " . $css_path . "<br>";
}

// Test 6: Check schema types
echo "<h2>Test 6: Schema Types Data</h2>";
$schema_types = $instance->get_schema_types();
if (!empty($schema_types)) {
    echo "✅ Schema types loaded: " . count($schema_types) . " types<br>";
    echo "<ul>";
    foreach ($schema_types as $type => $label) {
        echo "<li><strong>$type</strong>: $label</li>";
    }
    echo "</ul>";
} else {
    echo "❌ No schema types found<br>";
}

// Test 7: Check statistics
echo "<h2>Test 7: Statistics Data</h2>";
try {
    $statistics = new KATA_SEO_Statistics();
    $overview = $statistics->get_overview();
    echo "✅ Statistics class instantiated<br>";
    echo "   - Total schemas: " . ($overview['total_schemas'] ?? 0) . "<br>";
    echo "   - Active schemas: " . ($overview['active_schemas'] ?? 0) . "<br>";
} catch (Exception $e) {
    echo "❌ Error loading statistics: " . $e->getMessage() . "<br>";
}

// Test 8: Try to include the page
echo "<h2>Test 8: Page Rendering Test</h2>";
echo "<div style='border: 2px solid #667eea; padding: 20px; margin: 20px 0; background: #f8fafc;'>";
echo "<h3>Rendering Schema Types Page:</h3>";
echo "<hr>";

try {
    ob_start();
    include $file_path;
    $output = ob_get_clean();
    
    if (!empty($output)) {
        echo "✅ Page rendered successfully (" . strlen($output) . " characters)<br>";
        echo "<div style='max-height: 400px; overflow: auto; border: 1px solid #ccc; padding: 10px; background: white; margin-top: 10px;'>";
        echo $output;
        echo "</div>";
    } else {
        echo "❌ Page rendered but output is empty<br>";
    }
} catch (Exception $e) {
    echo "❌ Error rendering page: " . $e->getMessage() . "<br>";
}

echo "</div>";

// Test 9: Check admin URL
echo "<h2>Test 9: Admin Page URL</h2>";
$page_url = admin_url('admin.php?page=kata-seo-schema-types');
echo "✅ Schema Types page URL: <a href='$page_url' target='_blank'>$page_url</a><br>";
echo "<br>";
echo "<a href='$page_url' class='button button-primary' target='_blank'>Open Schema Types Page</a>";

echo "<hr>";
echo "<h2>Test Summary</h2>";
echo "<p><strong>All tests completed!</strong> If you see ✅ for all tests, the Schema Types page should be working.</p>";
echo "<p>Click the button above to open the actual admin page.</p>";
