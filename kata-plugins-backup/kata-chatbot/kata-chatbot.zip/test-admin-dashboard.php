<?php
/**
 * Test Admin Dashboard
 * 
 * Direct test for admin dashboard functionality
 */

// Load WordPress
require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';

echo "<h1>🎛️ Admin Dashboard Test</h1>";
echo "<style>
body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
.success { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
.info { color: blue; }
pre { background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto; }
</style>";

// Set admin context
define('WP_ADMIN', true);
set_current_screen('kata-chatbot');

echo "<h2>📋 Test 1: Load Required Files</h2>";

$plugin_dir = dirname(__FILE__);
$files_to_load = [
    'includes/class-db-handler.php',
    'includes/class-admin.php'
];

foreach ($files_to_load as $file) {
    $file_path = $plugin_dir . '/' . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
        echo "<span class='success'>✅ Loaded: {$file}</span><br>";
    } else {
        echo "<span class='error'>❌ Missing: {$file}</span><br>";
    }
}

echo "<h2>🔧 Test 2: Initialize DB Handler</h2>";

try {
    $db_handler = new KataChatbot_DB_Handler();
    echo "<span class='success'>✅ DB Handler created successfully</span><br>";
    
    // Test get_conversations_for_admin method
    if (method_exists($db_handler, 'get_conversations_for_admin')) {
        echo "<span class='success'>✅ Method get_conversations_for_admin exists</span><br>";
        
        $conversations_data = $db_handler->get_conversations_for_admin(1, 10);
        echo "<span class='success'>✅ Method executed successfully</span><br>";
        echo "<span class='info'>📊 Structure: " . print_r(array_keys($conversations_data), true) . "</span><br>";
        echo "<span class='info'>📊 Conversations count: " . count($conversations_data['conversations']) . "</span><br>";
        
    } else {
        echo "<span class='error'>❌ Method get_conversations_for_admin missing</span><br>";
    }
    
    // Test dashboard stats
    if (method_exists($db_handler, 'get_dashboard_stats')) {
        $stats = $db_handler->get_dashboard_stats();
        echo "<span class='success'>✅ Dashboard stats retrieved</span><br>";
        echo "<span class='info'>📊 Stats keys: " . implode(', ', array_keys($stats)) . "</span><br>";
    }
    
} catch (Exception $e) {
    echo "<span class='error'>❌ DB Handler error: " . $e->getMessage() . "</span><br>";
}

echo "<h2>🎛️ Test 3: Admin Dashboard Template</h2>";

try {
    // Simulate admin dashboard loading
    echo "<span class='info'>🔄 Loading admin dashboard template...</span><br>";
    
    // Set up variables like the real admin would
    $db_handler = new KataChatbot_DB_Handler();
    $stats = $db_handler->get_dashboard_stats();
    $conversations_data = $db_handler->get_conversations_for_admin(1, 10);
    $recent_conversations = $conversations_data['conversations'];
    
    echo "<span class='success'>✅ Variables prepared successfully</span><br>";
    echo "<span class='info'>📊 Stats available: " . (empty($stats) ? 'No' : 'Yes') . "</span><br>";
    echo "<span class='info'>📊 Recent conversations: " . count($recent_conversations) . "</span><br>";
    
    // Test template loading (capture output)
    ob_start();
    $template_path = $plugin_dir . '/templates/admin-dashboard.php';
    
    if (file_exists($template_path)) {
        include $template_path;
        $output = ob_get_contents();
        echo "<span class='success'>✅ Admin dashboard template loaded successfully</span><br>";
        echo "<span class='info'>📏 Template output size: " . strlen($output) . " bytes</span><br>";
    } else {
        echo "<span class='error'>❌ Admin dashboard template not found</span><br>";
    }
    ob_end_clean();
    
} catch (Exception $e) {
    ob_end_clean();
    echo "<span class='error'>❌ Template loading error: " . $e->getMessage() . "</span><br>";
}

echo "<h2>🏗️ Test 4: Admin Class Initialization</h2>";

try {
    if (class_exists('KataChatbot_Admin')) {
        echo "<span class='success'>✅ Admin class exists</span><br>";
        
        $admin = new KataChatbot_Admin();
        echo "<span class='success'>✅ Admin instance created</span><br>";
        
        // Test key methods
        $methods_to_test = [
            'add_admin_menu',
            'display_dashboard_page',
            'enqueue_admin_scripts',
            'register_settings'
        ];
        
        foreach ($methods_to_test as $method) {
            if (method_exists($admin, $method)) {
                echo "<span class='success'>✅ Method {$method} exists</span><br>";
            } else {
                echo "<span class='error'>❌ Method {$method} missing</span><br>";
            }
        }
        
    } else {
        echo "<span class='error'>❌ Admin class not found</span><br>";
    }
    
} catch (Exception $e) {
    echo "<span class='error'>❌ Admin class error: " . $e->getMessage() . "</span><br>";
}

echo "<h2>🎯 Test 5: Complete Integration Test</h2>";

try {
    // Simulate what happens when WordPress calls admin page
    echo "<span class='info'>🔄 Simulating WordPress admin page call...</span><br>";
    
    if (class_exists('KataChatbot_Admin')) {
        $admin = new KataChatbot_Admin();
        
        if (method_exists($admin, 'display_dashboard_page')) {
            echo "<span class='info'>🎛️ Calling display_dashboard_page method...</span><br>";
            
            // Capture the output
            ob_start();
            $admin->display_dashboard_page();
            $dashboard_output = ob_get_contents();
            ob_end_clean();
            
            if (!empty($dashboard_output)) {
                echo "<span class='success'>✅ Dashboard page rendered successfully</span><br>";
                echo "<span class='info'>📏 Dashboard output: " . strlen($dashboard_output) . " characters</span><br>";
                
                // Check for key elements
                if (strpos($dashboard_output, 'kata-chatbot-admin') !== false) {
                    echo "<span class='success'>✅ Dashboard contains main wrapper</span><br>";
                }
                
                if (strpos($dashboard_output, 'kata-stats-grid') !== false) {
                    echo "<span class='success'>✅ Dashboard contains stats grid</span><br>";
                }
                
            } else {
                echo "<span class='error'>❌ Dashboard page produced no output</span><br>";
            }
        }
    }
    
} catch (Exception $e) {
    echo "<span class='error'>❌ Integration test error: " . $e->getMessage() . "</span><br>";
    echo "<span class='error'>📍 Error details: " . $e->getTraceAsString() . "</span><br>";
}

echo "<h2>🎉 Test Summary</h2>";
echo "<div style='background: #f0f8ff; padding: 20px; border-radius: 8px; border-left: 4px solid #0073aa;'>";
echo "<h3>Admin Dashboard Status</h3>";
echo "<p>If all tests above show green checkmarks, the admin dashboard bug has been fixed!</p>";
echo "<p><strong>Next step:</strong> Try accessing the WordPress admin dashboard at:</p>";
echo "<p><a href='" . admin_url('admin.php?page=kata-chatbot') . "' target='_blank'>WordPress Admin → Kata Chatbot</a></p>";
echo "</div>";

?>
