# Kata SEO Tools - Hướng Dẫn Cài Đặt & Sử Dụng Nhanh

## 🚀 Cài Đặt Plugin

### **Bước 1: Upload Plugin**
```bash
# Option 1: Upload qua WordPress Admin
1. Đăng nhập WordPress Admin
2. Vào Plugins → Add New → Upload Plugin
3. Chọn file kata-seo-tools.zip
4. Click "Install Now"
5. Activate plugin

# Option 2: Upload qua FTP
1. Upload thư mục kata-seo-tools vào wp-content/plugins/
2. Vào WordPress Admin → Plugins
3. Activate "Kata SEO Tools"
```

### **Bước 2: Kiểm Tra Database**
Plugin sẽ tự động tạo các bảng sau:
- `wp_kata_seo_quiz_results`
- `wp_kata_seo_poll_votes`
- `wp_kata_seo_wheel_spins`
- `wp_kata_seo_ratings`
- `wp_kata_seo_form_submissions`
- `wp_kata_seo_social_shares`

### **Bước 3: Cấu Hình Cơ Bản**
```
1. Vào Kata SEO → Settings
2. Cấu hình:
   - Company Name
   - Company Logo
   - Social Media Profiles
   - Default Schema Type
3. Enable/Disable các tính năng theo nhu cầu
4. Save Settings
```

---

## ⚡ Quick Start - Sử Dụng Ngay

### **1. Thêm Schema Markup (Tự động)**

Khi edit Post/Page, bạn sẽ thấy meta box "Schema Markup" ở sidebar:

```
✓ Enable Schema Markup: [✓]
Schema Type: [Article ▼]
  - Article
  - BlogPosting  
  - NewsArticle
  - Tutorial
```

**Kết quả:** Schema tự động xuất hiện trong `<head>` của bài viết

---

### **2. Thêm Social Share Buttons**

Paste shortcode vào content editor:

```
[kata_social_share platforms="facebook,twitter,linkedin,tiktok"]
```

**Tùy chỉnh:**
```
[kata_social_share 
    platforms="facebook,twitter,linkedin" 
    style="circle" 
    size="large" 
    show_count="yes"
    title="Chia sẻ bài viết này"]
```

---

### **3. Tạo Quote với Hashtags**

```
[kata_quote style="modern" author="Steve Jobs" hashtags="#innovation #design"]
Stay hungry, stay foolish
[/kata_quote]
```

**Styles available:**
- `classic` - Traditional quote
- `modern` - Modern design với border-left
- `minimal` - Minimalist style
- `boxed` - Boxed với shadow
- `gradient` - Gradient background

---

### **4. Thêm Quiz**

**Bước 1:** Tạo quiz JSON configuration:

```json
{
  "id": "quiz-seo-basic",
  "title": "Kiểm tra kiến thức SEO",
  "questions": [
    {
      "question": "SEO là viết tắt của gì?",
      "options": [
        "Search Engine Optimization",
        "Social Engine Optimization",
        "Server Engine Optimization"
      ],
      "correct": 0
    },
    {
      "question": "On-page SEO là gì?",
      "options": [
        "Tối ưu hóa nội dung trong website",
        "Tối ưu hóa backlink",
        "Quảng cáo Google Ads"
      ],
      "correct": 0
    }
  ]
}
```

**Bước 2:** Encode JSON sang Base64 (sử dụng tool online hoặc PHP):
```php
$json = '{"questions":[...]}';
$encoded = base64_encode($json);
```

**Bước 3:** Paste shortcode:
```
[kata_quiz id="quiz-seo-basic" questions="BASE64_ENCODED_DATA"]
```

---

### **5. Thêm Poll**

```
[kata_poll 
    id="poll-cms" 
    question="CMS nào bạn thích nhất?"
    options='["WordPress", "Drupal", "Joomla"]']
```

**Kết quả:**
```
┌─ CMS nào bạn thích nhất? ────────────┐
│                                       │
│ ○ WordPress                           │
│   ████████████████████ 65% (120)      │
│                                       │
│ ○ Drupal                              │
│   ██████ 20% (37)                     │
│                                       │
│ ○ Joomla                              │
│   ████ 15% (28)                       │
│                                       │
│ [ Vote ]                              │
└───────────────────────────────────────┘
```

---

### **6. Thêm Vòng Quay May Mắn**

```json
{
  "prizes": [
    {"name": "Giảm 50%", "probability": 10, "color": "#FF6B6B"},
    {"name": "Giảm 30%", "probability": 20, "color": "#4ECDC4"},
    {"name": "Giảm 10%", "probability": 30, "color": "#45B7D1"},
    {"name": "Thử lại", "probability": 40, "color": "#95E1D3"}
  ]
}
```

**Shortcode:**
```
[kata_wheel id="wheel-promo" prizes="BASE64_ENCODED_PRIZES"]
```

---

### **7. Thêm Rating & Review**

```
[kata_rating show_average="yes" allow_review="yes"]
```

**Hiển thị:**
```
★★★★☆ 4.5/5 (123 đánh giá)

┌─ Viết đánh giá của bạn ─────────┐
│ Rating: ★★★★★                    │
│ Review: [____________]            │
│ [Submit Review]                   │
└──────────────────────────────────┘
```

---

### **8. Thêm Dynamic FAQ**

**Option 1: Sử dụng Meta Box**

Khi edit Post, tìm meta box "FAQ Schema":

```
[+ Add FAQ]

Q: SEO là gì?
A: SEO (Search Engine Optimization) là quá trình...

Q: On-page SEO bao gồm những gì?
A: On-page SEO bao gồm: Title tags, Meta description...

[Save]
```

**Option 2: Sử dụng Shortcode**

```
[kata_faq style="accordion" schema="yes"]
```

**Schema tự động:**
```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [...]
}
```

---

### **9. Thêm Call-to-Action (CTA)**

```
[kata_cta 
    style="box" 
    button_text="Đăng ký ngay" 
    button_url="/dang-ky"
    button_color="#FF6B6B"
    icon="🎁"]
Nhận ưu đãi 50% - Chỉ còn 3 ngày!
[/kata_cta]
```

**Sticky CTA (bottom bar):**
```
[kata_cta 
    style="sticky" 
    position="bottom"
    button_text="Liên hệ ngay"
    button_url="/lien-he"]
Hỗ trợ 24/7 - Hotline: 1900 xxxx
[/kata_cta]
```

---

### **10. Thêm Custom Form**

**Option 1: Sử dụng Form Builder (Admin)**

```
1. Vào Kata SEO → Forms → Add New
2. Drag & drop fields:
   - Name (Text)
   - Email (Email)
   - Phone (Tel)
   - Message (Textarea)
3. Configure settings
4. Save form
5. Copy shortcode: [kata_form id="contact-form"]
```

**Option 2: Shortcode trực tiếp**

```
[kata_form 
    id="quick-contact"
    title="Liên hệ với chúng tôi"
    fields='[
        {"type":"text","name":"name","label":"Họ tên","required":true},
        {"type":"email","name":"email","label":"Email","required":true},
        {"type":"textarea","name":"message","label":"Tin nhắn"}
    ]'
    submit_text="Gửi tin nhắn"
    success_message="Cảm ơn bạn đã liên hệ!"]
```

---

## 🎯 Use Cases Thực Tế

### **Use Case 1: Blog Post SEO đầy đủ**

```php
// Title: "10 Cách Tối Ưu SEO On-Page Hiệu Quả"

// 1. Schema Markup (Auto)
Meta Box: Schema Type = "Article"

// 2. Quote đầu bài
[kata_quote style="modern" author="Neil Patel" hashtags="#seo #onpage"]
Content is the reason search began in the first place
[/kata_quote]

// 3. Main content...

// 4. FAQ Schema
Meta Box FAQ:
Q: On-page SEO là gì?
A: On-page SEO là...

Q: Title tag nên dài bao nhiêu?
A: Từ 50-60 ký tự...

// 5. Quiz kiểm tra kiến thức
[kata_quiz id="quiz-onpage-seo" title="Kiểm tra kiến thức On-Page SEO"]

// 6. Rating
[kata_rating show_average="yes" allow_review="yes"]

// 7. Social Share
[kata_social_share platforms="facebook,twitter,linkedin" style="circle"]

// 8. CTA cuối bài
[kata_cta style="box" button_text="Tìm hiểu khóa học" button_url="/khoa-hoc"]
Học SEO chuyên sâu với chuyên gia hàng đầu!
[/kata_cta]
```

---

### **Use Case 2: Landing Page Promotion**

```php
// Title: "Khuyến Mãi Đặc Biệt - Giảm 50%"

// 1. Wheel Promotion
[kata_wheel id="black-friday" prizes="..."]

// 2. Poll Survey
[kata_poll 
    id="interest-survey" 
    question="Bạn quan tâm đến khóa học nào?"
    options='["SEO", "Content Marketing", "Social Media"]']

// 3. Registration Form
[kata_form 
    id="promo-registration"
    title="Đăng ký nhận ưu đãi"
    fields='[...]']

// 4. Sticky CTA
[kata_cta style="sticky" position="bottom" button_text="Đăng ký ngay"]
Chỉ còn 100 suất - Đăng ký ngay!
[/kata_cta]
```

---

### **Use Case 3: Bài Viết Hướng Dẫn (Tutorial)**

```php
// Title: "Hướng Dẫn SEO Từ A-Z Cho Người Mới"

// 1. Schema
Meta Box: Schema Type = "Tutorial"

// 2. FAQ đầy đủ
[kata_faq style="accordion" schema="yes"]
(10-15 câu hỏi thường gặp)

// 3. Quiz đánh giá
[kata_quiz id="seo-beginner-test"]

// 4. Social Share
[kata_social_share platforms="all" show_count="yes"]

// 5. Related CTA
[kata_cta style="banner" button_text="Xem video hướng dẫn"]
Xem video chi tiết trên YouTube!
[/kata_cta]
```

---

## 📊 Xem Analytics

```
1. Vào Kata SEO → Analytics
2. Chọn date range
3. Xem metrics:
   - Quiz completion rate
   - Poll participation
   - Social shares by platform
   - Rating statistics
   - Form submissions
   - CTA click-through rate
4. Export CSV/PDF report
```

---

## 🎨 Customization

### **Custom CSS:**

```css
/* Trong Kata SEO → Settings → Advanced → Custom CSS */

/* Custom quote style */
.kata-quote-modern {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 15px;
}

/* Custom social button */
.kata-social-btn {
    transition: transform 0.3s ease;
}

.kata-social-btn:hover {
    transform: scale(1.1);
}

/* Custom CTA */
.kata-cta-box {
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}
```

### **Custom JS:**

```javascript
/* Trong Kata SEO → Settings → Advanced → Custom JS */

// Track CTA clicks
jQuery('.kata-cta-button').on('click', function() {
    gtag('event', 'cta_click', {
        'cta_id': jQuery(this).data('id')
    });
});

// Custom quiz completion event
jQuery(document).on('kata_quiz_completed', function(e, data) {
    console.log('Quiz score:', data.score);
    // Send to analytics...
});
```

---

## 🔧 Troubleshooting

### **Schema không hiển thị:**
```
1. Kiểm tra meta box "Schema Markup" có được enable
2. Clear cache (nếu dùng caching plugin)
3. Test với Google Rich Results Test
```

### **Social share không track:**
```
1. Kiểm tra JavaScript console có lỗi không
2. Verify AJAX URL correct
3. Check database table wp_kata_seo_social_shares tồn tại
```

### **Quiz không submit:**
```
1. Check tất cả câu hỏi đã được trả lời
2. Verify nonce trong console
3. Check PHP error log
```

### **Form không gửi:**
```
1. Test reCAPTCHA (nếu enabled)
2. Check email settings
3. Verify SMTP configuration
```

---

## 📞 Hỗ Trợ

**Cần giúp đỡ?**

1. Đọc documentation: `/wp-content/plugins/kata-seo-tools/README.md`
2. Xem video tutorials
3. Liên hệ support: support@timona.vn
4. Forum: https://timona.vn/support

---

## ✅ Checklist Sau Khi Cài Đặt

- [ ] Plugin đã được activate
- [ ] Database tables đã được tạo
- [ ] Settings đã được cấu hình
- [ ] Test schema markup với Google Rich Results Test
- [ ] Test social share buttons
- [ ] Test quiz/poll functionality
- [ ] Test form submissions
- [ ] Enable analytics tracking
- [ ] Configure email notifications
- [ ] Setup backup cho database tables

---

**Chúc bạn sử dụng plugin hiệu quả! 🎉**

**Kata Team**  
*Making SEO & Engagement Easy*
