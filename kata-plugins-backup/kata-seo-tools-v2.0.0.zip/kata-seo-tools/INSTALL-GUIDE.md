# KATA SEO Tools - Installation Guide

## 📦 Cài đặt Plugin

### Phương pháp 1: Upload ZIP trong WordPress Admin (Khuyến nghị)

1. **Download file ZIP**
   - Tải file `kata-seo-tools.zip`

2. **Upload qua WordPress Admin**
   - Vào **WordPress Admin** → **Plugins** → **Add New**
   - Click nút **Upload Plugin** ở đầu trang
   - Click **Choose File** và chọn `kata-seo-tools.zip`
   - Click **Install Now**
   - Đợi quá trình upload và cài đặt hoàn tất

3. **Kích hoạt Plugin**
   - Sau khi cài đặt xong, click **Activate Plugin**
   - Plugin sẽ tự động tạo các bảng database cần thiết

4. **Xác nhận cài đặt thành công**
   - Vào **Plugins** → **Installed Plugins**
   - Kiểm tra **KATA SEO Tools** có status là **Active**
   - Check database có 6 bảng mới: `wp_kata_seo_*`

### Phương pháp 2: Upload qua FTP

1. **Giải nén file ZIP**
   ```bash
   unzip kata-seo-tools.zip
   ```

2. **Upload qua FTP**
   - Kết nối FTP đến server
   - Navigate đến `/wp-content/plugins/`
   - Upload toàn bộ folder `kata-seo-tools`
   - Đảm bảo permissions: `755` cho folders, `644` cho files

3. **Kích hoạt trong WordPress**
   - Vào **WordPress Admin** → **Plugins**
   - Tìm **KATA SEO Tools**
   - Click **Activate**

4. **Kiểm tra Database Tables**
   ```sql
   SHOW TABLES LIKE 'wp_kata_seo_%';
   ```
   Phải có 6 bảng:
   - `wp_kata_seo_quiz_results`
   - `wp_kata_seo_poll_votes`
   - `wp_kata_seo_wheel_spins`
   - `wp_kata_seo_ratings`
   - `wp_kata_seo_form_submissions`
   - `wp_kata_seo_social_shares`

### Phương pháp 3: WP-CLI

```bash
# Upload file ZIP lên server trước
wp plugin install /path/to/kata-seo-tools.zip --activate

# Kiểm tra plugin đã active
wp plugin list --status=active | grep kata-seo

# Kiểm tra database tables
wp db query "SHOW TABLES LIKE 'wp_kata_seo_%';"
```

## 🔧 Cấu hình sau khi cài đặt

### Bước 1: Kiểm tra Database Tables

Chạy query sau trong phpMyAdmin hoặc MySQL:

```sql
-- Check tables exist
SHOW TABLES LIKE 'wp_kata_seo_%';

-- Check quiz results table
DESCRIBE wp_kata_seo_quiz_results;

-- Check poll votes table
DESCRIBE wp_kata_seo_poll_votes;

-- Check wheel spins table
DESCRIBE wp_kata_seo_wheel_spins;

-- Check ratings table
DESCRIBE wp_kata_seo_ratings;

-- Check form submissions table
DESCRIBE wp_kata_seo_form_submissions;

-- Check social shares table
DESCRIBE wp_kata_seo_social_shares;
```

### Bước 2: Kiểm tra Plugin Files

Đảm bảo các file quan trọng tồn tại:

```
kata-seo-tools/
├── kata-seo-tools.php (Main file)
├── README.md
├── CHANGELOG.md
├── LICENSE.txt
├── includes/
│   ├── class-quiz-handler.php
│   ├── class-poll-handler.php
│   ├── class-wheel-handler.php
│   ├── class-rating-handler.php
│   ├── class-faq-handler.php
│   ├── class-quote-generator.php
│   ├── class-social-share.php
│   ├── class-cta-handler.php
│   └── class-form-handler.php
├── templates/
│   └── admin/
│       ├── schema-meta-box.php
│       ├── social-meta-box.php
│       └── faq-meta-box.php
└── assets/
    ├── css/
    └── js/
```

### Bước 3: Test Schema Markup

1. **Tạo/Edit bài viết**
   - Vào **Posts** → **Add New** hoặc edit bài viết có sẵn

2. **Bật Schema Markup**
   - Scroll xuống meta box **"KATA Schema Markup"**
   - Tích checkbox **"Bật Schema Markup cho bài viết này"**

3. **Chọn Schema Types**
   - Chọn ít nhất 1 schema type (VD: Article)
   - Hoặc chọn nhiều types (VD: Article + Product + Review)

4. **Lưu bài viết**
   - Click **Update** hoặc **Publish**

5. **Kiểm tra Output**
   - Mở bài viết trên frontend
   - View page source (Ctrl+U hoặc Cmd+U)
   - Tìm `<script type="application/ld+json">`
   - Verify JSON-LD code có đúng không

6. **Validate với Google**
   - Copy URL bài viết
   - Vào https://search.google.com/test/rich-results
   - Paste URL và click **Test URL**
   - Kiểm tra kết quả validation

## 🐛 Troubleshooting

### Lỗi: Database tables không được tạo

**Nguyên nhân:** Plugin activation hook không chạy

**Giải pháp 1 - Deactivate/Reactivate:**
```
1. Vào Plugins
2. Deactivate KATA SEO Tools
3. Activate lại
4. Check database tables
```

**Giải pháp 2 - Manual creation:**
```php
// Thêm vào functions.php (temporary)
add_action('init', function() {
    if (!get_option('kata_seo_tables_created')) {
        $plugin = Kata_SEO_Tools::get_instance();
        $plugin->create_database_tables();
        update_option('kata_seo_tables_created', 1);
    }
});
```

**Giải pháp 3 - Direct SQL:**
Chạy file SQL trong phpMyAdmin (xem `database-schema.sql`)

### Lỗi: Schema không xuất hiện

**Kiểm tra:**
1. Schema đã enabled cho bài viết?
   ```php
   get_post_meta(POST_ID, '_kata_seo_schema_enabled', true);
   ```

2. Schema types đã được chọn?
   ```php
   get_post_meta(POST_ID, '_kata_seo_schema_types', true);
   ```

3. Có lỗi PHP không?
   - Check `wp-content/debug.log`
   - Enable debug: `define('WP_DEBUG', true);` in `wp-config.php`

### Lỗi: Plugin conflict

**Giải pháp:**
1. Deactivate tất cả plugins khác
2. Activate KATA SEO Tools
3. Activate lại từng plugin để tìm conflict
4. Report conflict cho support

### Lỗi: Memory exhausted

**Giải pháp:**
```php
// Thêm vào wp-config.php
define('WP_MEMORY_LIMIT', '256M');
define('WP_MAX_MEMORY_LIMIT', '512M');
```

### Lỗi: Permission denied

**Giải pháp:**
```bash
# Set correct permissions
cd /wp-content/plugins/
chmod 755 kata-seo-tools
chmod 644 kata-seo-tools/*.php
chmod 755 kata-seo-tools/includes
chmod 755 kata-seo-tools/templates
chmod 755 kata-seo-tools/assets
```

## ✅ Post-Installation Checklist

- [ ] Plugin activated successfully
- [ ] 6 database tables created
- [ ] Schema meta box appears in post editor
- [ ] Test post with schema markup published
- [ ] JSON-LD visible in page source
- [ ] Google Rich Results Test passed
- [ ] No PHP errors in debug log
- [ ] No conflicts with other plugins

## 📞 Support

Nếu gặp vấn đề:

1. **Check Documentation**
   - README.md
   - CHANGELOG.md
   - This file (INSTALL.md)

2. **Debug Mode**
   ```php
   // wp-config.php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   define('WP_DEBUG_DISPLAY', false);
   ```

3. **Contact Support**
   - Email: support@timona.vn
   - Website: https://timona.vn

## 🔄 Update từ version cũ

### Từ v1.0.3 lên v2.0.0

1. **Backup trước khi update**
   ```bash
   # Backup database
   wp db export backup-$(date +%Y%m%d).sql
   
   # Backup plugin folder
   cp -r kata-seo-tools kata-seo-tools-backup
   ```

2. **Update plugin**
   - Deactivate v1.0.3
   - Delete old plugin files
   - Upload v2.0.0 ZIP
   - Activate

3. **Migration tự động**
   - Plugin tự động convert single schema → array
   - Legacy data được giữ nguyên
   - Không cần migration thủ công

4. **Verify sau update**
   - Check bài viết cũ vẫn có schema
   - Test chức năng mới (multiple schemas)
   - Validate với Google

---

**Version 2.0.0** | Installation Guide | Kata Team © 2025
