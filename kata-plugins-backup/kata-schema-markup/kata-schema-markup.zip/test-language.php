<?php
/**
 * Test script để kiểm tra ngôn ngữ tiếng Việt
 */

// Load WordPress
require_once(__DIR__ . '/../../wp-load.php');

// Test các string dịch
echo "<h2>Kiểm tra bản dịch tiếng Việt cho Kata Schema Markup</h2>\n";

$test_strings = [
    'Schema Markup' => __('Schema Markup', 'kata-schema-markup'),
    'Dashboard' => __('Dashboard', 'kata-schema-markup'),
    'Settings' => __('Settings', 'kata-schema-markup'),
    'Tools' => __('Tools', 'kata-schema-markup'),
    'Validation' => __('Validation', 'kata-schema-markup'),
    'Templates' => __('Templates', 'kata-schema-markup'),
    'Enable Schema' => __('Enable Schema', 'kata-schema-markup'),
    'Schema Type' => __('Schema Type', 'kata-schema-markup'),
    'Generate Schema' => __('Generate Schema', 'kata-schema-markup'),
    'Validate Schema' => __('Validate Schema', 'kata-schema-markup'),
    'Article' => __('Article', 'kata-schema-markup'),
    'Product' => __('Product', 'kata-schema-markup'),
    'Organization' => __('Organization', 'kata-schema-markup'),
];

echo "<table border='1' style='border-collapse: collapse; width: 100%;'>\n";
echo "<tr><th>English</th><th>Vietnamese</th><th>Status</th></tr>\n";

foreach ($test_strings as $english => $translated) {
    $status = ($english !== $translated) ? 
        "<span style='color: green;'>✓ Đã dịch</span>" : 
        "<span style='color: red;'>✗ Chưa dịch</span>";
    
    echo "<tr>";
    echo "<td>{$english}</td>";
    echo "<td>{$translated}</td>";
    echo "<td>{$status}</td>";
    echo "</tr>\n";
}

echo "</table>\n";

// Kiểm tra locale
echo "<h3>Thông tin locale:</h3>\n";
echo "<p><strong>WordPress Locale:</strong> " . get_locale() . "</p>\n";
echo "<p><strong>User Locale:</strong> " . get_user_locale() . "</p>\n";
echo "<p><strong>Site Language:</strong> " . get_bloginfo('language') . "</p>\n";

// Kiểm tra file tồn tại
$plugin_dir = plugin_dir_path(__FILE__);
$mo_file = $plugin_dir . 'languages/kata-schema-markup-vi.mo';
$po_file = $plugin_dir . 'languages/kata-schema-markup-vi.po';

echo "<h3>Kiểm tra files ngôn ngữ:</h3>\n";
echo "<p><strong>.mo file:</strong> " . (file_exists($mo_file) ? "✓ Tồn tại" : "✗ Không tồn tại") . "</p>\n";
echo "<p><strong>.po file:</strong> " . (file_exists($po_file) ? "✓ Tồn tại" : "✗ Không tồn tại") . "</p>\n";

if (file_exists($mo_file)) {
    echo "<p><strong>.mo file size:</strong> " . filesize($mo_file) . " bytes</p>\n";
}

echo "<h3>Hướng dẫn:</h3>\n";
echo "<ul>";
echo "<li>Nếu các chuỗi chưa được dịch, hãy kiểm tra locale WordPress</li>";
echo "<li>Đảm bảo wp-config.php có: <code>define('WPLANG', 'vi');</code></li>";
echo "<li>Xóa cache và reload trang</li>";
echo "<li>Kiểm tra file .mo đã được tạo đúng</li>";
echo "</ul>";
?>
