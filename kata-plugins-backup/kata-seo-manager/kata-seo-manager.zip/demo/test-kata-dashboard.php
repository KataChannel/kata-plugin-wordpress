<?php
/**
 * KATA SEO Manager Demo Dashboard Test
 * Script kiểm tra dashboard và statistics sau khi tạo demo posts
 */

// Include WordPress
require_once('wp-config.php');
require_once('wp-load.php');

echo "🔍 KATA SEO Manager Dashboard Test\n";
echo "==================================\n\n";

// 1. Kiểm tra demo posts đã tạo
echo "📊 1. Kiểm tra Demo Posts:\n";
$demo_posts = get_posts(array(
    'posts_per_page' => -1,
    'meta_key' => '_kata_seo_demo_post',
    'meta_value' => true,
    'post_status' => 'publish'
));

echo "✅ Tổng số demo posts: " . count($demo_posts) . "\n";

// Group by schema type
$schema_counts = array();
foreach ($demo_posts as $post) {
    $schema_type = get_post_meta($post->ID, '_kata_seo_schema_type', true);
    if (!isset($schema_counts[$schema_type])) {
        $schema_counts[$schema_type] = 0;
    }
    $schema_counts[$schema_type]++;
}

echo "\n📋 Phân loại theo Schema Type:\n";
foreach ($schema_counts as $type => $count) {
    echo "   - {$type}: {$count} bài\n";
}

// 2. Kiểm tra KATA SEO database tables
echo "\n🗄️ 2. Kiểm tra Database Tables:\n";
global $wpdb;

$tables_to_check = array(
    $wpdb->prefix . 'kata_seo_schemas',
    $wpdb->prefix . 'kata_seo_analytics',
    $wpdb->prefix . 'kata_seo_settings',
    $wpdb->prefix . 'kata_seo_cache'
);

foreach ($tables_to_check as $table) {
    $exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
    if ($exists) {
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        echo "   ✅ {$table}: {$count} records\n";
    } else {
        echo "   ❌ {$table}: Không tồn tại\n";
    }
}

// 3. Kiểm tra shortcodes trong content
echo "\n🔧 3. Kiểm tra Shortcodes:\n";
$shortcode_stats = array();

foreach ($demo_posts as $post) {
    $content = $post->post_content;
    
    // Find all KATA shortcodes
    preg_match_all('/\[kata_([^\]]+)/', $content, $matches);
    
    if (!empty($matches[1])) {
        foreach ($matches[1] as $shortcode) {
            $shortcode_name = explode(' ', $shortcode)[0]; // Get shortcode name only
            if (!isset($shortcode_stats[$shortcode_name])) {
                $shortcode_stats[$shortcode_name] = 0;
            }
            $shortcode_stats[$shortcode_name]++;
        }
    }
}

echo "📈 Thống kê shortcodes sử dụng:\n";
foreach ($shortcode_stats as $shortcode => $count) {
    echo "   - kata_{$shortcode}: {$count} lần\n";
}

// 4. Test shortcode rendering
echo "\n🎨 4. Test Shortcode Rendering:\n";

// Test một vài shortcodes
$test_posts = array_slice($demo_posts, 0, 3); // Test 3 posts đầu

foreach ($test_posts as $post) {
    echo "   📄 Testing: {$post->post_title}\n";
    
    $content = apply_filters('the_content', $post->post_content);
    
    // Check if JSON-LD exists in output
    if (strpos($content, 'application/ld+json') !== false) {
        echo "      ✅ JSON-LD Schema generated\n";
    } else {
        echo "      ❌ No JSON-LD Schema found\n";
    }
    
    // Check shortcode processing
    if (strpos($content, '[kata_') !== false) {
        echo "      ⚠️  Shortcode chưa được process\n";
    } else {
        echo "      ✅ Shortcode đã được process\n";
    }
}

// 5. Kiểm tra plugin activation
echo "\n🔌 5. Kiểm tra Plugin Status:\n";

if (is_plugin_active('kata-seo-manager/kata-seo-manager.php')) {
    echo "   ✅ KATA SEO Manager: Active\n";
} else {
    echo "   ❌ KATA SEO Manager: Inactive\n";
}

// Check if shortcodes are registered
$registered_shortcodes = array();
global $shortcode_tags;

foreach ($shortcode_tags as $tag => $callback) {
    if (strpos($tag, 'kata_') === 0) {
        $registered_shortcodes[] = $tag;
    }
}

echo "   📋 Registered KATA shortcodes: " . count($registered_shortcodes) . "\n";
foreach ($registered_shortcodes as $shortcode) {
    echo "      - {$shortcode}\n";
}

// 6. Performance stats
echo "\n⚡ 6. Performance Stats:\n";

$total_posts = wp_count_posts()->publish;
$demo_percentage = round((count($demo_posts) / $total_posts) * 100, 2);

echo "   📊 Total posts: {$total_posts}\n";
echo "   🧪 Demo posts: " . count($demo_posts) . " ({$demo_percentage}%)\n";

// Memory usage
$memory_usage = memory_get_usage(true);
$memory_peak = memory_get_peak_usage(true);

echo "   💾 Memory usage: " . formatBytes($memory_usage) . "\n";
echo "   📈 Peak memory: " . formatBytes($memory_peak) . "\n";

// 7. SEO Check
echo "\n🔍 7. SEO Validation:\n";

// Check first demo post for SEO elements
$first_post = $demo_posts[0];
$post_content = apply_filters('the_content', $first_post->post_content);

// Check meta tags
$has_og_tags = strpos($post_content, 'og:') !== false;
$has_twitter_cards = strpos($post_content, 'twitter:') !== false;
$has_schema = strpos($post_content, 'application/ld+json') !== false;

echo "   🏷️  Open Graph tags: " . ($has_og_tags ? "✅" : "❌") . "\n";
echo "   🐦 Twitter Cards: " . ($has_twitter_cards ? "✅" : "❌") . "\n";
echo "   📊 Schema Markup: " . ($has_schema ? "✅" : "❌") . "\n";

// 8. Summary
echo "\n📋 8. SUMMARY REPORT:\n";
echo "==================\n";
echo "✅ Demo posts created: " . count($demo_posts) . "/27\n";
echo "📊 Schema types covered: " . count($schema_counts) . "/27\n";
echo "🔧 Shortcodes registered: " . count($registered_shortcodes) . "\n";

if (count($demo_posts) == 27 && count($schema_counts) == 27) {
    echo "🎉 STATUS: ALL TESTS PASSED!\n";
    echo "🚀 KATA SEO Manager đã sẵn sàng sử dụng!\n";
} else {
    echo "⚠️  STATUS: SOME ISSUES FOUND\n";
    echo "🔧 Cần kiểm tra lại một số vấn đề\n";
}

echo "\n📱 Next Steps:\n";
echo "1. Vào Admin Dashboard → Posts để xem demo posts\n";
echo "2. Kiểm tra frontend để xem JSON-LD Schema\n";
echo "3. Test Google Rich Results với Google Testing Tool\n"; 
echo "4. Kiểm tra KATA SEO Manager admin page\n";

echo "\n✨ Test completed!\n";

// Helper function
function formatBytes($size, $precision = 2) {
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}
?>