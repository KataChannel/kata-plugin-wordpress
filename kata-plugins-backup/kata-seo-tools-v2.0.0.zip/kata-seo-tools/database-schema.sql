-- ============================================
-- KATA SEO Tools - Database Schema
-- Version: 2.0.0
-- Description: SQL schema for all plugin tables
-- ============================================

-- This file is for reference only.
-- Tables are automatically created when plugin is activated.
-- Use this only for manual recovery or troubleshooting.

-- ============================================
-- Table: kata_seo_quiz_results
-- Purpose: Store quiz completion results
-- ============================================

CREATE TABLE IF NOT EXISTS `wp_kata_seo_quiz_results` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL COMMENT 'Post ID where quiz is located',
  `quiz_id` varchar(100) NOT NULL COMMENT 'Unique quiz identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'WordPress user ID (if logged in)',
  `score` int(11) NOT NULL COMMENT 'Quiz score',
  `total_questions` int(11) NOT NULL COMMENT 'Total number of questions',
  `answers` longtext COMMENT 'JSON encoded answers',
  `completion_time` int(11) DEFAULT NULL COMMENT 'Time to complete in seconds',
  `ip_address` varchar(100) DEFAULT NULL COMMENT 'User IP address',
  `user_agent` text COMMENT 'Browser user agent',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Quiz results and completions';

-- ============================================
-- Table: kata_seo_poll_votes
-- Purpose: Store poll voting data
-- ============================================

CREATE TABLE IF NOT EXISTS `wp_kata_seo_poll_votes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL COMMENT 'Post ID where poll is located',
  `poll_id` varchar(100) NOT NULL COMMENT 'Unique poll identifier',
  `option_id` int(11) NOT NULL COMMENT 'Selected option ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'WordPress user ID (if logged in)',
  `ip_address` varchar(100) DEFAULT NULL COMMENT 'User IP address',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `poll_id` (`poll_id`),
  KEY `option_id` (`option_id`),
  UNIQUE KEY `unique_vote` (`poll_id`, `ip_address`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Poll votes';

-- ============================================
-- Table: kata_seo_wheel_spins
-- Purpose: Store wheel of fortune spin results
-- ============================================

CREATE TABLE IF NOT EXISTS `wp_kata_seo_wheel_spins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL COMMENT 'Post ID where wheel is located',
  `wheel_id` varchar(100) NOT NULL COMMENT 'Unique wheel identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'WordPress user ID (if logged in)',
  `prize_id` int(11) NOT NULL COMMENT 'Won prize ID',
  `prize_name` varchar(255) DEFAULT NULL COMMENT 'Won prize name',
  `ip_address` varchar(100) DEFAULT NULL COMMENT 'User IP address',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `wheel_id` (`wheel_id`),
  KEY `user_id` (`user_id`),
  KEY `prize_id` (`prize_id`),
  UNIQUE KEY `unique_spin` (`wheel_id`, `ip_address`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Wheel of fortune spins';

-- ============================================
-- Table: kata_seo_ratings
-- Purpose: Store post ratings and reviews
-- ============================================

CREATE TABLE IF NOT EXISTS `wp_kata_seo_ratings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL COMMENT 'Rated post ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'WordPress user ID (if logged in)',
  `rating` int(1) NOT NULL COMMENT 'Rating value (1-5)',
  `review` text COMMENT 'Review text',
  `ip_address` varchar(100) DEFAULT NULL COMMENT 'User IP address',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `user_id` (`user_id`),
  KEY `rating` (`rating`),
  UNIQUE KEY `unique_rating` (`post_id`, `user_id`, `ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Post ratings and reviews';

-- ============================================
-- Table: kata_seo_form_submissions
-- Purpose: Store form submission data
-- ============================================

CREATE TABLE IF NOT EXISTS `wp_kata_seo_form_submissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL COMMENT 'Post ID where form is located',
  `form_id` varchar(100) NOT NULL COMMENT 'Unique form identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'WordPress user ID (if logged in)',
  `form_data` longtext COMMENT 'JSON encoded form data',
  `ip_address` varchar(100) DEFAULT NULL COMMENT 'User IP address',
  `user_agent` text COMMENT 'Browser user agent',
  `status` varchar(20) DEFAULT 'pending' COMMENT 'Submission status: pending, processed, spam',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Form submissions';

-- ============================================
-- Table: kata_seo_social_shares
-- Purpose: Track social media shares
-- ============================================

CREATE TABLE IF NOT EXISTS `wp_kata_seo_social_shares` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL COMMENT 'Shared post ID',
  `platform` varchar(50) NOT NULL COMMENT 'Social platform: facebook, twitter, linkedin, etc',
  `share_count` int(11) DEFAULT 1 COMMENT 'Number of shares',
  `last_shared` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Last share timestamp',
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `platform` (`platform`),
  UNIQUE KEY `unique_share` (`post_id`, `platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Social media shares tracking';

-- ============================================
-- Post Meta Keys Reference
-- ============================================

-- Schema Markup
-- _kata_seo_schema_enabled (1 or 0)
-- _kata_seo_schema_types (serialized array)
-- _kata_seo_schema_type (legacy single type)

-- Product Schema
-- _kata_seo_product_price
-- _kata_seo_product_currency
-- _kata_seo_product_brand
-- _kata_seo_product_availability

-- Review Schema
-- _kata_seo_review_rating
-- _kata_seo_review_item

-- Recipe Schema
-- _kata_seo_recipe_prep_time
-- _kata_seo_recipe_cook_time
-- _kata_seo_recipe_calories

-- Event Schema
-- _kata_seo_event_start_date
-- _kata_seo_event_end_date
-- _kata_seo_event_location

-- Video Schema
-- _kata_seo_video_duration
-- _kata_seo_video_upload_date
-- _kata_seo_video_thumbnail

-- Course Schema
-- _kata_seo_course_provider
-- _kata_seo_course_price

-- HowTo Schema
-- _kata_seo_howto_total_time
-- _kata_seo_howto_supply
-- _kata_seo_howto_tool

-- JobPosting Schema
-- _kata_seo_job_salary
-- _kata_seo_job_location
-- _kata_seo_job_date_posted
-- _kata_seo_job_valid_through

-- LocalBusiness Schema
-- _kata_seo_business_address
-- _kata_seo_business_phone
-- _kata_seo_business_hours

-- Social Meta
-- _kata_seo_og_title
-- _kata_seo_og_description
-- _kata_seo_og_image
-- _kata_seo_twitter_card

-- FAQ
-- _kata_seo_faqs (serialized array)

-- ============================================
-- Sample Data Queries
-- ============================================

-- Get quiz statistics
-- SELECT quiz_id, COUNT(*) as total_attempts, AVG(score) as avg_score
-- FROM wp_kata_seo_quiz_results
-- GROUP BY quiz_id;

-- Get poll results
-- SELECT poll_id, option_id, COUNT(*) as votes
-- FROM wp_kata_seo_poll_votes
-- GROUP BY poll_id, option_id;

-- Get wheel prizes distribution
-- SELECT wheel_id, prize_name, COUNT(*) as times_won
-- FROM wp_kata_seo_wheel_spins
-- GROUP BY wheel_id, prize_name;

-- Get average ratings per post
-- SELECT post_id, AVG(rating) as avg_rating, COUNT(*) as total_ratings
-- FROM wp_kata_seo_ratings
-- GROUP BY post_id;

-- Get social shares by platform
-- SELECT platform, SUM(share_count) as total_shares
-- FROM wp_kata_seo_social_shares
-- GROUP BY platform;

-- ============================================
-- Maintenance Queries
-- ============================================

-- Clean old quiz results (older than 90 days)
-- DELETE FROM wp_kata_seo_quiz_results WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

-- Clean spam form submissions
-- DELETE FROM wp_kata_seo_form_submissions WHERE status = 'spam' AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- Optimize tables
-- OPTIMIZE TABLE wp_kata_seo_quiz_results;
-- OPTIMIZE TABLE wp_kata_seo_poll_votes;
-- OPTIMIZE TABLE wp_kata_seo_wheel_spins;
-- OPTIMIZE TABLE wp_kata_seo_ratings;
-- OPTIMIZE TABLE wp_kata_seo_form_submissions;
-- OPTIMIZE TABLE wp_kata_seo_social_shares;

-- ============================================
-- Backup Commands
-- ============================================

-- Backup all KATA SEO tables
-- mysqldump -u username -p database_name wp_kata_seo_quiz_results wp_kata_seo_poll_votes wp_kata_seo_wheel_spins wp_kata_seo_ratings wp_kata_seo_form_submissions wp_kata_seo_social_shares > kata_seo_backup.sql

-- Restore from backup
-- mysql -u username -p database_name < kata_seo_backup.sql

-- ============================================
-- End of Schema
-- ============================================
-- Version: 2.0.0
-- Date: 2025-01-08
-- Maintained by: Kata Team
-- ============================================
